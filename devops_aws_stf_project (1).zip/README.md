# Proyecto DevOps en AWS - Soluciones Tecnológicas del Futuro

Este repositorio contiene la infraestructura como código, scripts de automatización y configuración de CI/CD para automatizar el despliegue y monitoreo de aplicaciones en AWS.
