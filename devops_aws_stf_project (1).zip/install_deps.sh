#!/bin/bash
sudo apt update
sudo apt install -y docker.io git python3 python3-pip
